# EDLINE ARENA – Classic PB

ไฟล์ต้นแบบเกม FPS บนเว็บ (fan-inspired original prototype)

## วิธีเปิดเล่น
- เปิด `index.html` ผ่านเว็บเซิร์ฟเวอร์หรือ GitHub Pages
- ต้องเชื่อมต่ออินเทอร์เน็ตเพื่อโหลด Three.js จาก CDN
- บนคอม: WASD เดิน, เมาส์หมุนมุมมอง, คลิกหรือ Space ยิง, R รีโหลด
- บนมือถือ: ใช้วงกลมซ้ายเดิน, ลากพื้นที่สนามเพื่อหมุนมุมมอง, FIRE ยิง, RELOAD รีโหลด

## เผยแพร่ผ่าน GitHub Pages
1. อัปโหลด `index.html` และ `README.md` ไปยัง repository `edline-arena`
2. เข้า Settings > Pages
3. เลือก Deploy from a branch
4. เลือก Branch `main` และ Folder `/(root)` แล้วกด Save
5. รอให้ GitHub Pages เผยแพร่เว็บไซต์

## ขอบเขตของเวอร์ชันนี้
- มีหน้า Lobby จำลอง, เลือกห้องฝึก, สนาม 3D, เดิน, เล็ง, ยิงเป้าหมาย และรีโหลด
- ยังไม่ใช่เกมออนไลน์หลายคนจริง ไม่มีระบบบัญชี/เซิร์ฟเวอร์/ห้องออนไลน์หรือแชต
- ใช้ชื่อและงานภาพต้นฉบับ ไม่รวมไฟล์หรือทรัพย์สินทางการของ Point Blank
