-- PB STRIKE ONLINE: Supabase schema
-- Run this whole file in Supabase SQL Editor before launching the app.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  email text,
  role text not null default 'player' check (role in ('player','admin','super_admin')),
  points bigint not null default 0 check (points >= 0),
  diamonds bigint not null default 0 check (diamonds >= 0),
  level integer not null default 1 check (level >= 1),
  exp bigint not null default 0 check (exp >= 0),
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  mode text not null default 'Team Deathmatch',
  status text not null default 'WAITING',
  player_count integer not null default 0,
  max_players integer not null default 16,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists public.admin_audit (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  target_user_id uuid references auth.users(id),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','super_admin') and is_banned=false); $$;

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='super_admin' and is_banned=false); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,username,email)
 values(new.id,coalesce(nullif(new.raw_user_meta_data->>'username',''),split_part(new.email,'@',1)),new.email);
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Only admins can adjust balances. Delta may be positive or negative; no negative resulting balance.
create or replace function public.admin_adjust_balance(target_user_id uuid,balance_type text,amount_delta bigint)
returns void language plpgsql security definer set search_path=public
as $$
begin
 if not public.is_admin() then raise exception 'admin access required'; end if;
 if balance_type not in ('points','diamonds') then raise exception 'invalid balance type'; end if;
 if amount_delta=0 then raise exception 'amount cannot be zero'; end if;
 if balance_type='points' then
   update public.profiles set points=points+amount_delta where id=target_user_id and points+amount_delta>=0;
 else
   update public.profiles set diamonds=diamonds+amount_delta where id=target_user_id and diamonds+amount_delta>=0;
 end if;
 if not found then raise exception 'member not found or insufficient balance'; end if;
 insert into public.admin_audit(actor_id,action,target_user_id,details)
 values(auth.uid(),'adjust_'||balance_type,target_user_id,jsonb_build_object('delta',amount_delta));
end; $$;

alter table public.profiles enable row level security;
alter table public.game_rooms enable row level security;
alter table public.admin_audit enable row level security;

drop policy if exists "profiles read own or admin" on public.profiles;
create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
-- Profile fields that grant privileges or change balances are writable only by SUPER ADMIN.
-- Ordinary players cannot update their own role, wallet, ban status, or EXP through the client.
drop policy if exists "profile owner updates safe fields" on public.profiles;
drop policy if exists "admins update profiles" on public.profiles;
create policy "super admins update profiles" on public.profiles for update to authenticated
using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists "authenticated read rooms" on public.game_rooms;
create policy "authenticated read rooms" on public.game_rooms for select to authenticated using (true);
drop policy if exists "members create rooms" on public.game_rooms;
create policy "members create rooms" on public.game_rooms for insert to authenticated
with check (created_by=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and is_banned=false));
drop policy if exists "admins manage rooms" on public.game_rooms;
create policy "admins manage rooms" on public.game_rooms for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins read audit" on public.admin_audit;
create policy "admins read audit" on public.admin_audit for select to authenticated using (public.is_admin());
drop policy if exists "admins write audit" on public.admin_audit;
create policy "admins write audit" on public.admin_audit for insert to authenticated with check (public.is_admin() and actor_id=auth.uid());

grant usage on schema public to authenticated;
grant select,update on public.profiles to authenticated;
grant select,insert,update,delete on public.game_rooms to authenticated;
grant select,insert on public.admin_audit to authenticated;
grant execute on function public.admin_adjust_balance(uuid,text,bigint) to authenticated;

-- IMPORTANT: after creating your own account, run the bootstrap statement from README
-- using your own Auth user UUID. Never put a service_role key in the browser.
