import express from "express";
import http from "http";
import { Server } from "socket.io";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import dotenv from "dotenv";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 24) {
  console.error("Set JWT_SECRET to a random secret of at least 24 characters in .env");
  process.exit(1);
}
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "pbstrike.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'PLAYER',
 banned INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS rooms (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 mode TEXT NOT NULL,
 map TEXT NOT NULL,
 max_players INTEGER NOT NULL DEFAULT 8,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);
const findUser = db.prepare("SELECT * FROM users WHERE username = ?");
const insertUser = db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)");
const adminName = process.env.SUPER_ADMIN_USERNAME || "owner";
const adminPass = process.env.SUPER_ADMIN_PASSWORD;
if (!findUser.get(adminName)) {
  if (!adminPass || adminPass.length < 12) {
    console.error("Set SUPER_ADMIN_PASSWORD to at least 12 characters before first start.");
    process.exit(1);
  }
  insertUser.run(adminName, bcrypt.hashSync(adminPass, 12), "SUPER_ADMIN");
  console.log(`Created first SUPER_ADMIN account: ${adminName}`);
}

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false } });
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.get("/api/health", (_req, res) => res.json({ ok: true, name: "PB STRIKE ONLINE" }));

function tokenFor(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  try {
    const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare("SELECT id,username,role,banned FROM users WHERE id=?").get(payload.id);
    if (!user || user.banned) return res.status(403).json({ error: "บัญชีนี้ไม่สามารถเข้าใช้งานได้" });
    req.user = user; next();
  } catch { return res.status(401).json({ error: "กรุณาเข้าสู่ระบบใหม่" }); }
}
const adminOnly = (req,res,next) => req.user?.role === "SUPER_ADMIN" ? next() : res.status(403).json({error:"เฉพาะ SUPER ADMIN"});
app.post("/api/register", (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[A-Za-z0-9_]{3,18}$/.test(username)) return res.status(400).json({error:"ชื่อผู้ใช้ 3-18 ตัว ใช้ A-Z, 0-9 และ _"});
  if (password.length < 8) return res.status(400).json({error:"รหัสผ่านต้องมีอย่างน้อย 8 ตัว"});
  try {
    const info = insertUser.run(username, bcrypt.hashSync(password, 12), "PLAYER");
    const user = { id: Number(info.lastInsertRowid), username, role:"PLAYER" };
    res.json({ token:tokenFor(user), user });
  } catch { res.status(409).json({error:"ชื่อผู้ใช้นี้ถูกใช้แล้ว"}); }
});
app.post("/api/login", (req,res) => {
  const user = findUser.get(String(req.body.username || "").trim());
  if (!user || !bcrypt.compareSync(String(req.body.password || ""), user.password_hash)) return res.status(401).json({error:"ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"});
  if (user.banned) return res.status(403).json({error:"บัญชีนี้ถูกระงับ"});
  res.json({token:tokenFor(user), user:{id:user.id,username:user.username,role:user.role}});
});
app.get("/api/me", auth, (req,res) => res.json({user:req.user}));
app.get("/api/rooms", auth, (_req,res) => res.json({rooms:[...rooms.values()].map(publicRoom)}));
app.get("/api/admin/users", auth, adminOnly, (_req,res) => {
  res.json({users:db.prepare("SELECT id,username,role,banned,created_at FROM users ORDER BY id").all()});
});
app.post("/api/admin/users/:id/ban", auth, adminOnly, (req,res) => {
  const id = Number(req.params.id);
  const target = db.prepare("SELECT id,role FROM users WHERE id=?").get(id);
  if (!target) return res.status(404).json({error:"ไม่พบสมาชิก"});
  if (target.role === "SUPER_ADMIN") return res.status(400).json({error:"ไม่สามารถแบน SUPER ADMIN ได้"});
  db.prepare("UPDATE users SET banned=? WHERE id=?").run(req.body.banned ? 1 : 0, id);
  res.json({ok:true});
});

const rooms = new Map();
const socketsByUser = new Map();
function publicRoom(r) { return {id:r.id,name:r.name,mode:r.mode,map:r.map,maxPlayers:r.maxPlayers,players:r.players.size}; }
function authSocket(socket,next) {
  try {
    const p = jwt.verify(socket.handshake.auth?.token || "", JWT_SECRET);
    const user = db.prepare("SELECT id,username,role,banned FROM users WHERE id=?").get(p.id);
    if (!user || user.banned) return next(new Error("unauthorized"));
    socket.user = user; next();
  } catch { next(new Error("unauthorized")); }
}
io.use(authSocket);
io.on("connection", socket => {
  const user = socket.user;
  socketsByUser.set(user.id, socket.id);
  socket.emit("lobby:rooms", [...rooms.values()].map(publicRoom));
  socket.on("room:create", data => {
    const name = String(data?.name || "ห้องใหม่").slice(0,28);
    const mode = ["Team Deathmatch","Shotgun","Bomb"].includes(data?.mode) ? data.mode : "Team Deathmatch";
    const id = Math.random().toString(36).slice(2,8).toUpperCase();
    const room = {id,name,mode,map:"Training Yard",maxPlayers:8,players:new Map(),bullets:[]};
    rooms.set(id,room); joinRoom(socket,room);
    broadcastRooms();
  });
  socket.on("room:join", id => {
    const room = rooms.get(String(id));
    if (!room || room.players.size >= room.maxPlayers) return socket.emit("notice","ห้องเต็มหรือไม่พบห้อง");
    joinRoom(socket,room); broadcastRooms();
  });
  socket.on("game:move", data => {
    const room = rooms.get(socket.data.roomId); if (!room) return;
    const p = room.players.get(socket.id); if (!p) return;
    p.x = clamp(Number(data?.x), 24, 976); p.y = clamp(Number(data?.y), 24, 576);
    p.angle = Number(data?.angle) || 0;
    socket.to(room.id).emit("game:player", {id:socket.id,player:p});
  });
  socket.on("game:shoot", data => {
    const room = rooms.get(socket.data.roomId); if (!room) return;
    const p = room.players.get(socket.id); if (!p) return;
    const bullet = {id:Math.random().toString(36).slice(2),owner:socket.id,x:p.x,y:p.y,angle:Number(data?.angle)||0,life:700};
    room.bullets.push(bullet); io.to(room.id).emit("game:bullet",bullet);
  });
  socket.on("disconnect", () => {
    socketsByUser.delete(user.id);
    const room = rooms.get(socket.data.roomId);
    if (room) { room.players.delete(socket.id); socket.to(room.id).emit("game:left",socket.id); if (!room.players.size) rooms.delete(room.id); }
    broadcastRooms();
  });
});
function joinRoom(socket,room) {
  if (socket.data.roomId) socket.leave(socket.data.roomId);
  socket.data.roomId=room.id; socket.join(room.id);
  const player={username:socket.user.username,x:100+Math.random()*700,y:100+Math.random()*350,angle:0,hp:100};
  room.players.set(socket.id,player);
  socket.emit("game:joined",{room:publicRoom(room),players:[...room.players].map(([id,p])=>({id,player:p}))});
  socket.to(room.id).emit("game:entered",{id:socket.id,player});
}
function broadcastRooms(){ const list=[...rooms.values()].map(publicRoom); io.emit("lobby:rooms",list); }
function clamp(n,min,max){return Number.isFinite(n)?Math.max(min,Math.min(max,n)):min;}
server.listen(PORT,()=>console.log(`PB STRIKE ONLINE running on http://localhost:${PORT}`));
