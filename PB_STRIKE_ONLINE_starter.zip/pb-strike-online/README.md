# PB STRIKE ONLINE

A fresh, original browser-game starter inspired by the broad lobby/HUD ideas in your references. It does not copy the source website's code, branding assets, maps, or proprietary game content.

## Included
- Responsive Thai game lobby for Chrome, Safari, desktop and mobile
- Registration and login with bcrypt password hashing and JWT sessions
- First-run SUPER ADMIN account seeded from environment variables
- Server/channel selection, room list, create/join room
- 2D top-down browser shooter prototype with keyboard/mouse and mobile touch controls
- Real-time room state and player movement/shooting using Socket.IO
- SQLite persistence for users and room records
- Admin panel to view users and ban/unban accounts

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set a unique `JWT_SECRET` and a strong `SUPER_ADMIN_PASSWORD`.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

The SUPER ADMIN is created on first server start only if the username does not already exist. Keep `.env` private. Never publish it or commit it to Git.

## Deploy for real online play
Deploy this Node app to a host that supports persistent Node processes and WebSockets (for example, a VPS or a Node-compatible platform). Attach persistent storage for `data/pbstrike.sqlite`, set the environment variables, and use HTTPS. Use a managed database or shared persistent volume before scaling to multiple server instances. A single instance supports real-time rooms; production scale needs authoritative game simulation, rate limits, monitoring, backups, anti-cheat, moderation and load testing.

## Important prototype limits
This is an original 2D top-down shooter prototype, not a full 3D Point Blank clone. The current game has basic movement and hitscan-style shooting; it is a foundation for further maps, weapons, animation, matchmaking and dedicated authoritative simulation. Real internet availability begins only after you deploy it to a public host and configure its domain.
